﻿using System.Runtime.Serialization;

namespace ActsModel.Model
{
    [DataContract]
    public class ActIndividual : ActBase
    {
        
    }
}